package com.example.rrmeasure.ui.main;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Point;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

import androidx.annotation.Nullable;

public class CircleViewWithProgress extends View {

    private Point mCenterPoint;
    private float mRadius;
    private float mPreviousFinishAngle = 270;
    private float mFillingPercentage;
    private int mPercentage;
    private int mProgressBarColor;

    private RectF mRectF;
    private Paint mPaint;

    public CircleViewWithProgress(Context context) {
        super(context);
        mPaint = new Paint();
        mRectF = new RectF();
    }

    public CircleViewWithProgress(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        mPaint = new Paint();
        mRectF = new RectF();
    }

    public CircleViewWithProgress(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        mPaint = new Paint();
        mRectF = new RectF();
    }

    public CircleViewWithProgress(Context context, @Nullable AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
        mPaint = new Paint();
        mRectF = new RectF();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        mPaint = new Paint();
        if(mCenterPoint == null) {
            mCenterPoint = new Point (getWidth() / 2, getHeight() / 2);
            /*
             * if radius extends to edges, but if circular code
             * exists already then we should already know what the
             * radius is at this point I would assume.
             */
            mRadius = getWidth() / 2;

            mRectF.set(mCenterPoint.x-275, mCenterPoint.y-275, mCenterPoint.x+275, mCenterPoint.y+275);

            mPaint.setStyle(Paint.Style.STROKE);
//            mPaint.setColor(MainViewModel.COLOR_LTGRAY);
            mPaint.setStrokeWidth(40f);
            canvas.drawArc(mRectF, 0f, 360f, false, mPaint);
        }

        mFillingPercentage = (float) (360 * (mPercentage / 1000.0));
        mPaint.setColor(mProgressBarColor);
        canvas.drawArc(mRectF, mPreviousFinishAngle, mFillingPercentage, false, mPaint);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        Point touchedPoint = new Point(Math.round(event.getX()),   Math.round(event.getY()));
        if (isInsideCircle(touchedPoint)) {
            return super.onTouchEvent(event);
        }
        return true;
    }

    private boolean isInsideCircle(Point touchedPoint) {
        int distance = (int) Math.round(Math.pow(touchedPoint.x - mCenterPoint.x, 2) +
                Math.pow(touchedPoint.y - mCenterPoint.y, 2));
        return distance < Math.pow(mRadius, 2);
    }

    public void setPercentage(int percentage) {
        this.mPercentage = percentage;
        invalidate();
    }

    public void setProgressColor(int color) {
        mProgressBarColor = color;
        mPreviousFinishAngle = mFillingPercentage;
    }
}
