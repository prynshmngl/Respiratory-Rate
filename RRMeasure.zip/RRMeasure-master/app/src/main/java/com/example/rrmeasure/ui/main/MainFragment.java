package com.example.rrmeasure.ui.main;

import androidx.cardview.widget.CardView;
import androidx.lifecycle.ViewModelProviders;

import android.content.Context;
import android.os.Build;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.os.CountDownTimer;
import android.os.Vibrator;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.example.rrmeasure.R;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

public class MainFragment extends Fragment {

    private MainViewModel mViewModel;

    private CircleView mTapView;
    private Button mResetButton;
    private TextView mTextView;
//    private CircleMenu mCircleMenu;
//    private View mAnimateView;
    private ProgressBar mProgressBar;
    private LinearLayout mIndicatorContainer;

    private ArrayList<CardView> mIndicatorList;

    CountDownTimer mOneMinTimer = new CountDownTimer(MainViewModel.MAX_TIME_TO_CALC_IN_MILLIS,
            100) {
        @Override
        public void onTick(long millisUntilFinished) {
            int progress = (int) ((MainViewModel.MAX_TIME_TO_CALC_IN_MILLIS - millisUntilFinished)
                    * 1000 / MainViewModel.MAX_TIME_TO_CALC_IN_MILLIS);
            if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                mProgressBar.setProgress(progress, true);
//                mTapView.setPercentage(progress);
            } else {
                mProgressBar.setProgress(progress);
//                mTapView.setPercentage(progress);
            }
        }

        @Override
        public void onFinish() {
            if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                mProgressBar.setProgress(1000, true);
            } else {
                mProgressBar.setProgress(1000);
            }
            String text = "";
            int tapCount = mViewModel.getTapCount();
            if (tapCount > 3) {
                text += "Inconsistent Taps";
            } else if (tapCount < 1) {
                text += "No Taps";
            } else {
                text += "Insufficient Taps";
            }
            text += "\nPLease try again";
            stopRRCalculation(text);
        }
    };

    public static MainFragment newInstance() {
        return new MainFragment();
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.main_fragment, container, false);
        mTextView = root.findViewById(R.id.rr_text_view);
        mTapView = root.findViewById(R.id.tap_button);
        mResetButton = root.findViewById(R.id.reset_button);
//        mCircleMenu = root.findViewById(R.id.circle_menu);
        mProgressBar = root.findViewById(R.id.progress_circular);
//        mAnimateView = root.findViewById(R.id.animated_circle);
        mIndicatorContainer = root.findViewById(R.id.indicator_container);
        setIndicatorIcons();
        return root;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        mViewModel = ViewModelProviders.of(this).get(MainViewModel.class);
        final Vibrator vibe = (Vibrator) getContext().getSystemService(Context.VIBRATOR_SERVICE);
        mTapView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                assert vibe != null;
                vibe.vibrate(20);
                if (mViewModel.getTapCount() >= MainViewModel.MAX_TAPS_ALLOWED) {
                    stopRRCalculation("Max Taps\n Please try again");
                    return;
                } else if (mViewModel.getTapCount() == 0) {
                    mViewModel.setPreviousTapTime(System.currentTimeMillis());
                    mViewModel.setIsCalculatingRR(true);
                    mOneMinTimer.start();
                    mResetButton.setVisibility(View.VISIBLE);
//                    mTapView.setProgressColor(mViewModel.getColorList().get(0));
                    startRRCalculation();
                } else {
                    long currentTapTime = System.currentTimeMillis();
                    mViewModel.addTimerListItem(currentTapTime - mViewModel.getPreviousTapTime());
                    mViewModel.setPreviousTapTime(currentTapTime);
//                    mTapView.setProgressColor(mViewModel.getColorList().get(1));
                    calculateAverageRR();
                }
                mIndicatorList.get(mViewModel.getTapCount()).setCardBackgroundColor(getResources().
                        getColor(R.color.indicator_icon_selected));
                mViewModel.incrementTapCount();
            }
        });

        mResetButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resetActivity();
            }
        });
    }

    private void calculateAverageRR() {
        ArrayList<Long> timerList = mViewModel.getTimerList();
        List<Long> itemListForMedian = timerList.subList(Math.max(timerList.size() -
                MainViewModel.ITEM_COUNT_FOR_MEDIAN_CALC, 0), timerList.size());
        int medianListSize;
        medianListSize = itemListForMedian.size();
        if (medianListSize < MainViewModel.ITEM_COUNT_FOR_MEDIAN_CALC) {
            return;
        }
        Collections.sort(itemListForMedian);
        double medianTime = itemListForMedian.get(medianListSize/2);
        int maxConsistencyVariation = 0;
        for (long time : itemListForMedian) {
            maxConsistencyVariation = (int) Math.max((Math.abs(time - medianTime) / medianTime) * 100, maxConsistencyVariation);
        }

        if (maxConsistencyVariation < MainViewModel.THRESHOLD_CONSISTENCY_PERCENTAGE) {
            int rr = (int) (60000 / medianTime);
            rr = rr- (int) (MainViewModel.ERROR_FACTOR*(0.01));
            stopRRCalculation(rr + "/min");
        }
    }

    private void stopRRCalculation(String text) {
        mViewModel.setIsCalculatingRR(false);
        mOneMinTimer.cancel();
        mTapView.setEnabled(false);
        mTapView.setClickable(false);
        mTextView.setText(text);
        mResetButton.setVisibility(View.VISIBLE);
        if (mProgressBar.getProgress() != 1000) {
            setCalculationProgress(1000);
        }
        endCircleAnimation();
    }

    private void startRRCalculation() {
//        Animation circleAnimation = AnimationUtils.loadAnimation(getContext(), R.anim.circle_view_animation);
//        mAnimateView.setVisibility(View.GONE);
//        mAnimateView.startAnimation(circleAnimation);
        mTextView.setText("TAP on Inhalation");
        setCalculationProgress(0);
    }

    private void endCircleAnimation() {
//        mAnimateView.clearAnimation();
    }

    private void resetActivity() {
        mTapView.setEnabled(true);
        mTapView.setClickable(true);
        mTextView.setText("TAP to START");
        mViewModel.invalidateData();
        mResetButton.setVisibility(View.GONE);
        mOneMinTimer.cancel();
        setIndicatorIcons();
        setCalculationProgress(0);
    }

    private void setCalculationProgress(int progress) {
        mProgressBar.setMax(10);
        mProgressBar.setMax(1000);
        if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            mProgressBar.setProgress(progress, true);
        } else {
            mProgressBar.setProgress(progress);
        }
//        mTapView.setPercentage(progress);
    }

    private void setIndicatorIcons() {
        mIndicatorList = new ArrayList<>();
        mIndicatorContainer.removeAllViews();
        for (int i = 0; i < MainViewModel.MAX_TAPS_ALLOWED; i++) {
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                    30,
                    30
            );
            params.setMarginEnd(10);
            params.setMarginStart(10);

            CardView cardView = new CardView(Objects.requireNonNull(getContext()));
            cardView.setRadius(15f);
            cardView.setCardBackgroundColor(getResources().getColor(R.color.indicator_icon_unselected));
            cardView.setLayoutParams(params);
            cardView.setCardElevation(0);
            mIndicatorContainer.addView(cardView);
            mIndicatorList.add(cardView);
        }
    }
}
